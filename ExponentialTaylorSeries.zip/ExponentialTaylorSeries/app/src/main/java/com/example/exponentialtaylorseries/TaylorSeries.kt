package com.example.exponentialtaylorseries

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_exponentiation.*
import kotlinx.android.synthetic.main.activity_taylor_series.*
import net.objecthunter.exp4j.ExpressionBuilder
import kotlin.math.pow

class TaylorSeries : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_taylor_series)
        b2.setOnClickListener(){
            val back2= Intent(this,MainActivity::class.java)
            startActivity(back2)
        }

        compute1.setOnClickListener(){
            val a=input1.text.toString().toDouble()
            val b=imput2.text.toString().toInt()
            val t=sine(a,b).toString()
            val expression=ExpressionBuilder(t).build()
            val r=expression.evaluate()
            var round= String.format("%.5f",r)
            sineresult.text=round
        }

    }

private fun sine(x: Double, n: Int): Double {
    val p=x*((3.14)/180.0)
    var y = 0
    var ans = 0.0
    var ansi=0.0
    while (y<=n) {
        if (y % 2 == 0) {
            ans+=(p.pow(2*y+1)/factorial(2*y+1))
        }
        else{
            ansi+=(p.pow(2*y+1) / factorial(2*y+1))
        }
        y++
    }
    return (ans-ansi)
}
private fun factorial(x: Int): Long {
    var i = 1
    var ans:Long = 1;
    if (x == 0) {
        return 1
    }
    while (i <= x) {
        ans *= i
        i++
    }
    return ans
}
  }

