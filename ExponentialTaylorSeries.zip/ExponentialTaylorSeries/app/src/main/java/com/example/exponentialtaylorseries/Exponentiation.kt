package com.example.exponentialtaylorseries

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import kotlinx.android.synthetic.main.activity_exponentiation.*
import net.objecthunter.exp4j.ExpressionBuilder
import java.lang.Math.pow
import kotlin.math.pow

class Exponentiation : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exponentiation)
        e.text = (Html.fromHtml("e<sup>x</sup>: "))
        b1.setOnClickListener() {
            val back1 = Intent(this, MainActivity::class.java)
            startActivity(back1)

        }

        compute.setOnClickListener() {
            val a=x.text.toString().toDouble()
            val b=n.text.toString().toInt()
            val t=expo(a,b).toString()
            val expression=ExpressionBuilder(t).build()
            val r=expression.evaluate()
            result.text = r.toString()
        }
    }

      private fun expo(x: Double, n: Int): Double {
          var y = 1
          var ans = 0.0
          while (y <= n) {
              ans += x.pow(y)/factorial(y)
              y++
          }
          return (ans+1)
      }
        private fun factorial(x: Int): Int {
            var i = 1
            var ans = 1;
            if (x == 0) {
                return 1
            }
            while (i <= x) {
                ans *= i
                i++
            }
            return ans
        }
    }
