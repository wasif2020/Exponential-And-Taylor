package com.example.exponentialtaylorseries

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        expo.setOnClickListener(){
            val ex=Intent(this,Exponentiation::class.java)
            startActivity(ex)
        }
        sin.setOnClickListener(){
            val sin=Intent(this,TaylorSeries::class.java)
            startActivity(sin)
        }
        exit.setOnClickListener(){
            ActivityCompat.finishAffinity(this)
        }
    }
}